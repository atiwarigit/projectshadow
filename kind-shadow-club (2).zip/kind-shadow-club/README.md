# Kind Shadow Club — static site

One self-contained page. No build step, no dependencies, no server.
Fonts load from Google Fonts; everything else is inline.

## Deploy to Vercel — pick one

### A. Drag & drop (no terminal, ~2 min)
1. Go to https://vercel.com/new
2. Drop this whole `kind-shadow-club` folder onto the page (or zip it and upload).
3. Framework preset: **Other**. Root: the folder. Click **Deploy**.
   You'll get a live `*.vercel.app` URL.

### B. Vercel CLI (if you have Node)
    cd kind-shadow-club
    npx vercel            # first run links/logs you in
    npx vercel --prod     # promotes to your production URL

### C. GitHub → Vercel (best if you'll keep editing)
1. Make a new GitHub repo, add these files, push.
2. In Vercel: New Project → Import that repo → Deploy.
   Every future push auto-deploys.

## Custom domain
Vercel dashboard → Project → Settings → Domains → add your domain and follow the DNS steps.

## Files
- `index.html`  — the entire site
- `vercel.json` — clean URLs + basic security headers (optional)
